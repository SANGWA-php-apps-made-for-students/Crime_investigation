<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_evidence'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'evidence'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $evidence_id=$_SESSION['id_upd'];
                      
$evidence_type = $_POST['txt_evidence_type'];
$suspect = $_POST['txt_suspect_id'];

$entry_date = date("y-m-d");

$User = $_SESSION['userid'];

$points = $_POST['txt_points'];
$note = $_POST['txt_note'];
$image = $_POST['txt_image_id'];



$upd_obj->update_evidence($evidence_type, $suspect, $entry_date, $User, $points, $note, $image,$evidence_id);
unset($_SESSION['table_to_update']);
}}else{$evidence_type = $_POST['txt_evidence_type'];
$suspect =trim( $_POST['txt_suspect_id']);
$entry_date =date("y-m-d");
$User = $_SESSION['userid'];
$points = $_POST['txt_points'];
$note = $_POST['txt_note'];
$image =trim( $_POST['txt_image_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_evidence($evidence_type, $suspect, $entry_date, $User, $points, $note, $image);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
evidence</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_evidence.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_suspect_id"   name="txt_suspect_id"/><input type="hidden" id="txt_image_id"   name="txt_image_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
          <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

<div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 evidence saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  evidence Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_evidence_type">Evidence type </label></td><td> <input type="text"     name="txt_evidence_type" required id="txt_evidence_type" class="textbox" value="<?php echo trim(chosen_evidence_type_upd());?>"   />  </td></tr>
 <tr><td class="new_data_tb_frst_cols">Suspect </td><td> <?php get_suspect_combo(); ?>  </td></tr><tr><td><label for="txt_points">Points </label></td><td> <input type="text"     name="txt_points" required id="txt_points" class="textbox" value="<?php echo trim(chosen_points_upd());?>"   />  </td></tr>
<tr><td><label for="txt_note">Note </label></td><td> <input type="text"     name="txt_note" required id="txt_note" class="textbox" value="<?php echo trim(chosen_note_upd());?>"   />  </td></tr>
 <tr><td class="new_data_tb_frst_cols">Image </td><td> <?php get_image_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_evidence" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">evidence List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_evidence();
                    $obj->list_evidence($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
               
var suspect = '<?php echo chosen_suspect_upd(); ?>';        $('.cbo_suspect').val(suspect);
        $('#txt_suspect_id').val(suspect);
    
        
var image = '<?php echo chosen_image_upd(); ?>';        $('.cbo_image').val(image);
        $('#txt_image_id').val(image);
    
     }
</script>
</body>
</hmtl>
<?php
function chosen_evidence_type_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $evidence_type = new multi_values();
               return $evidence_type->get_chosen_evidence_evidence_type($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_suspect_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $suspect = new multi_values();
               return $suspect->get_chosen_evidence_suspect($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $entry_date = new multi_values();
               return $entry_date->get_chosen_evidence_entry_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $User = new multi_values();
               return $User->get_chosen_evidence_User($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_points_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $points = new multi_values();
               return $points->get_chosen_evidence_points($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_note_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $note = new multi_values();
               return $note->get_chosen_evidence_note($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'evidence') {               $id = $_SESSION['id_upd'];
               $image = new multi_values();
               return $image->get_chosen_evidence_image($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}

function get_suspect_combo() {
    $obj = new multi_values();
    $obj->get_suspect_in_combo();
}
function get_suspect_combo() {
    $obj = new multi_values();
    $obj->get_suspect_in_combo();
}
