
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `officer`
--

CREATE TABLE IF NOT EXISTS `officer` (
`officer_id`     int(11) NOT NULL AUTO_INCREMENT 
,`area`     VARCHAR(60) 
, `profile`     int(11)   

,PRIMARY KEY (`officer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `case`
--

CREATE TABLE IF NOT EXISTS `case` (
`case_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`name`     VARCHAR(60) 
,`note`     VARCHAR(60) 

,PRIMARY KEY (`case_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `officer_case`
--

CREATE TABLE IF NOT EXISTS `officer_case` (
`officer_case_id`     int(11) NOT NULL AUTO_INCREMENT 
, `officer`     int(11)   
, `case`     int(11)   

,PRIMARY KEY (`officer_case_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `suspect`
--

CREATE TABLE IF NOT EXISTS `suspect` (
`suspect_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `profile`     int(11)   
, `case`     int(11)   

,PRIMARY KEY (`suspect_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `evidence`
--

CREATE TABLE IF NOT EXISTS `evidence` (
`evidence_id`     int(11) NOT NULL AUTO_INCREMENT 
,`evidence_type`     VARCHAR(60) 
, `suspect`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`points`     VARCHAR(60) 
,`note`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`evidence_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
`history_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `case`     int(11)   
,`note`     VARCHAR(60) 

,PRIMARY KEY (`history_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
`result_id`     int(11) NOT NULL AUTO_INCREMENT 
, `suspect`     int(11)   
, `case`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`note`     VARCHAR(60) 

,PRIMARY KEY (`result_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

