<?php 
class new_values{

 function new_account(  $account_category, $date_created, $profile, $username, $password, $is_online){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':date_created'=>$date_created, ':profile'=>$profile, ':username'=>$username, ':password'=>$password, ':is_online'=>$is_online
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id, :name)");$stm->execute(array(':account_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence, ':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_image(  $path){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into image values(:image_id, :path)");$stm->execute(array(':image_id'=>0,':path'=>$path
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_officer(  $area, $profile){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into officer values(:officer_id, :area,  :profile)");$stm->execute(array(':officer_id'=>0,':area'=>$area, ':profile'=>$profile
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_case(  $entry_date, $User, $name, $note){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into case values(:case_id, :entry_date,  :User,  :name,  :note)");$stm->execute(array(':case_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':name'=>$name, ':note'=>$note
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_officer_case(  $officer, $case){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into officer_case values(:officer_case_id, :officer,  :case)");$stm->execute(array(':officer_case_id'=>0,':officer'=>$officer, ':case'=>$case
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_suspect(  $entry_date, $User, $profile, $case){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into suspect values(:suspect_id, :entry_date,  :User,  :profile,  :case)");$stm->execute(array(':suspect_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':profile'=>$profile, ':case'=>$case
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_evidence(  $evidence_type, $suspect, $entry_date, $User, $points, $note, $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into evidence values(:evidence_id, :evidence_type,  :suspect,  :entry_date,  :User,  :points,  :note,  :image)");$stm->execute(array(':evidence_id'=>0,':evidence_type'=>$evidence_type, ':suspect'=>$suspect, ':entry_date'=>$entry_date, ':User'=>$User, ':points'=>$points, ':note'=>$note, ':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_history(  $entry_date, $User, $case, $note){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into history values(:history_id, :entry_date,  :User,  :case,  :note)");$stm->execute(array(':history_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':case'=>$case, ':note'=>$note
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_result(  $suspect, $case, $entry_date, $User, $note){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into result values(:result_id, :suspect,  :case,  :entry_date,  :User,  :note)");$stm->execute(array(':result_id'=>0,':suspect'=>$suspect, ':case'=>$case, ':entry_date'=>$entry_date, ':User'=>$User, ':note'=>$note
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
