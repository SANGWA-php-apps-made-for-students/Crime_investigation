<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_officer( $area, $profile,$officer_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE officer set 
area= ?, profile= ? WHERE officer_id=?");
$stmt->execute(array($area, $profile ,$officer_id ));

}
 function update_case( $entry_date, $User, $name, $note,$case_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE case set 
entry_date= ?, User= ?, name= ?, note= ? WHERE case_id=?");
$stmt->execute(array($entry_date, $User, $name, $note ,$case_id ));

}
 function update_officer_case( $officer, $case,$officer_case_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE officer_case set 
officer= ?, case= ? WHERE officer_case_id=?");
$stmt->execute(array($officer, $case ,$officer_case_id ));

}
 function update_suspect( $entry_date, $User, $profile, $case,$suspect_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE suspect set 
entry_date= ?, User= ?, profile= ?, case= ? WHERE suspect_id=?");
$stmt->execute(array($entry_date, $User, $profile, $case ,$suspect_id ));

}
 function update_evidence( $evidence_type, $suspect, $entry_date, $User, $points, $note, $image,$evidence_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE evidence set 
evidence_type= ?, suspect= ?, entry_date= ?, User= ?, points= ?, note= ?, image= ? WHERE evidence_id=?");
$stmt->execute(array($evidence_type, $suspect, $entry_date, $User, $points, $note, $image ,$evidence_id ));

}
 function update_history( $entry_date, $User, $case, $note,$history_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE history set 
entry_date= ?, User= ?, case= ?, note= ? WHERE history_id=?");
$stmt->execute(array($entry_date, $User, $case, $note ,$history_id ));

}
 function update_result( $suspect, $case, $entry_date, $User, $note,$result_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE result set 
suspect= ?, case= ?, entry_date= ?, User= ?, note= ? WHERE result_id=?");
$stmt->execute(array($suspect, $case, $entry_date, $User, $note ,$result_id ));

}

}

