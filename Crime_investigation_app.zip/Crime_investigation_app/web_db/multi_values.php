<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['password']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['is_online']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id']; ?>"  data-table="account">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_category_id']; ?>"  data-table="account_category">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_category_id']; ?>" data-table="account_category" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_dob($id) {

            $db = new dbconnection();
            $sql = "select   profile.dob from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dob'];
            echo $field;
        }

        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_telephone_number($id) {

            $db = new dbconnection();
            $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone_number'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_residence($id) {

            $db = new dbconnection();
            $sql = "select   profile.residence from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['residence'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_image($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from image";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> image </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $this->_e($row['path']); ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['image_id']; ?>"  data-table="image">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" data-id_update="<?php echo $row['image_id']; ?>" data-table="image" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_image_path($id) {

            $db = new dbconnection();
            $sql = "select   image.path from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['path'];
            echo $field;
        }

        function All_image() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  image_id   from image";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_last_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function list_officer($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from officer";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> officer </td>
                    <td> Area </td><td> Profile with image </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['officer_id']; ?>
                    </td>
                    <td class="area_id_cols officer " title="officer" >
                        <?php echo $this->_e($row['area']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>


                    <td>
                        <a href="#" class="officer_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['officer_id']; ?>"  data-table="officer">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="officer_update_link" style="color: #000080;" data-id_update="<?php echo $row['officer_id']; ?>" data-table="officer" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_officer_area($id) {

            $db = new dbconnection();
            $sql = "select   officer.area from officer where officer_id=:officer_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':officer_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['area'];
            echo $field;
        }

        function get_chosen_officer_profile($id) {

            $db = new dbconnection();
            $sql = "select   officer.profile from officer where officer_id=:officer_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':officer_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function All_officer() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  officer_id   from officer";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_officer() {
            $con = new dbconnection();
            $sql = "select officer.officer_id from officer
                    order by officer.officer_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['officer_id'];
            return $first_rec;
        }

        function get_last_officer() {
            $con = new dbconnection();
            $sql = "select officer.officer_id from officer
                    order by officer.officer_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['officer_id'];
            return $first_rec;
        }

        function list_case($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from case";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> case </td>
                    <td> Entry Date </td><td> User </td><td> Name </td><td> Note </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['case_id']; ?>
                    </td>
                    <td class="entry_date_id_cols case " title="case" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['note']); ?>
                    </td>


                    <td>
                        <a href="#" class="case_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['case_id']; ?>"  data-table="case">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="case_update_link" style="color: #000080;" data-id_update="<?php echo $row['case_id']; ?>" data-table="case" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_case_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   case.entry_date from case where case_id=:case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_case_User($id) {

            $db = new dbconnection();
            $sql = "select   case.User from case where case_id=:case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_case_name($id) {

            $db = new dbconnection();
            $sql = "select   case.name from case where case_id=:case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_case_note($id) {

            $db = new dbconnection();
            $sql = "select   case.note from case where case_id=:case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['note'];
            echo $field;
        }

        function All_case() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  case_id   from case";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_case() {
            $con = new dbconnection();
            $sql = "select case.case_id from case
                    order by case.case_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['case_id'];
            return $first_rec;
        }

        function get_last_case() {
            $con = new dbconnection();
            $sql = "select case.case_id from case
                    order by case.case_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['case_id'];
            return $first_rec;
        }

        function list_officer_case($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from officer_case";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> officer_case </td>
                    <td> officer </td><td> Case </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['officer_case_id']; ?>
                    </td>
                    <td class="officer_id_cols officer_case " title="officer_case" >
                        <?php echo $this->_e($row['officer']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['case']); ?>
                    </td>


                    <td>
                        <a href="#" class="officer_case_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['officer_case_id']; ?>"  data-table="officer_case">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="officer_case_update_link" style="color: #000080;" data-id_update="<?php echo $row['officer_case_id']; ?>" data-table="officer_case" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_officer_case_officer($id) {

            $db = new dbconnection();
            $sql = "select   officer_case.officer from officer_case where officer_case_id=:officer_case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':officer_case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['officer'];
            echo $field;
        }

        function get_chosen_officer_case_case($id) {

            $db = new dbconnection();
            $sql = "select   officer_case.case from officer_case where officer_case_id=:officer_case_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':officer_case_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['case'];
            echo $field;
        }

        function All_officer_case() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  officer_case_id   from officer_case";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_officer_case() {
            $con = new dbconnection();
            $sql = "select officer_case.officer_case_id from officer_case
                    order by officer_case.officer_case_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['officer_case_id'];
            return $first_rec;
        }

        function get_last_officer_case() {
            $con = new dbconnection();
            $sql = "select officer_case.officer_case_id from officer_case
                    order by officer_case.officer_case_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['officer_case_id'];
            return $first_rec;
        }

        function list_suspect($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from suspect";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> suspect </td>
                    <td> Entry Date </td><td> User </td><td> Profile with image </td><td> Case </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['suspect_id']; ?>
                    </td>
                    <td class="entry_date_id_cols suspect " title="suspect" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['case']); ?>
                    </td>


                    <td>
                        <a href="#" class="suspect_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['suspect_id']; ?>"  data-table="suspect">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="suspect_update_link" style="color: #000080;" data-id_update="<?php echo $row['suspect_id']; ?>" data-table="suspect" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_suspect_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   suspect.entry_date from suspect where suspect_id=:suspect_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':suspect_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_suspect_User($id) {

            $db = new dbconnection();
            $sql = "select   suspect.User from suspect where suspect_id=:suspect_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':suspect_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_suspect_profile($id) {

            $db = new dbconnection();
            $sql = "select   suspect.profile from suspect where suspect_id=:suspect_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':suspect_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_suspect_case($id) {

            $db = new dbconnection();
            $sql = "select   suspect.case from suspect where suspect_id=:suspect_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':suspect_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['case'];
            echo $field;
        }

        function All_suspect() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  suspect_id   from suspect";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_suspect() {
            $con = new dbconnection();
            $sql = "select suspect.suspect_id from suspect
                    order by suspect.suspect_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['suspect_id'];
            return $first_rec;
        }

        function get_last_suspect() {
            $con = new dbconnection();
            $sql = "select suspect.suspect_id from suspect
                    order by suspect.suspect_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['suspect_id'];
            return $first_rec;
        }

        function list_evidence($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from evidence";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> evidence </td>
                    <td> Evidence type </td><td> Suspect </td><td> Entry Date </td><td> User </td><td> Points </td><td> Note </td><td> Image </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['evidence_id']; ?>
                    </td>
                    <td class="evidence_type_id_cols evidence " title="evidence" >
                        <?php echo $this->_e($row['evidence_type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['suspect']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['points']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['note']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="evidence_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['evidence_id']; ?>"  data-table="evidence">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="evidence_update_link" style="color: #000080;" data-id_update="<?php echo $row['evidence_id']; ?>" data-table="evidence" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_evidence_evidence_type($id) {

            $db = new dbconnection();
            $sql = "select   evidence.evidence_type from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['evidence_type'];
            echo $field;
        }

        function get_chosen_evidence_suspect($id) {

            $db = new dbconnection();
            $sql = "select   evidence.suspect from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['suspect'];
            echo $field;
        }

        function get_chosen_evidence_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   evidence.entry_date from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_evidence_User($id) {

            $db = new dbconnection();
            $sql = "select   evidence.User from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_evidence_points($id) {

            $db = new dbconnection();
            $sql = "select   evidence.points from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['points'];
            echo $field;
        }

        function get_chosen_evidence_note($id) {

            $db = new dbconnection();
            $sql = "select   evidence.note from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['note'];
            echo $field;
        }

        function get_chosen_evidence_image($id) {

            $db = new dbconnection();
            $sql = "select   evidence.image from evidence where evidence_id=:evidence_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':evidence_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_evidence() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  evidence_id   from evidence";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_evidence() {
            $con = new dbconnection();
            $sql = "select evidence.evidence_id from evidence
                    order by evidence.evidence_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['evidence_id'];
            return $first_rec;
        }

        function get_last_evidence() {
            $con = new dbconnection();
            $sql = "select evidence.evidence_id from evidence
                    order by evidence.evidence_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['evidence_id'];
            return $first_rec;
        }

        function list_history($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from history";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> history </td>
                    <td> Entry Date </td><td> User </td><td> Caee </td><td> Note </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['history_id']; ?>
                    </td>
                    <td class="entry_date_id_cols history " title="history" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['case']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['note']); ?>
                    </td>


                    <td>
                        <a href="#" class="history_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['history_id']; ?>"  data-table="history">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="history_update_link" style="color: #000080;" data-id_update="<?php echo $row['history_id']; ?>" data-table="history" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_history_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   history.entry_date from history where history_id=:history_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':history_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_history_User($id) {

            $db = new dbconnection();
            $sql = "select   history.User from history where history_id=:history_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':history_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_history_case($id) {

            $db = new dbconnection();
            $sql = "select   history.case from history where history_id=:history_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':history_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['case'];
            echo $field;
        }

        function get_chosen_history_note($id) {

            $db = new dbconnection();
            $sql = "select   history.note from history where history_id=:history_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':history_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['note'];
            echo $field;
        }

        function All_history() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  history_id   from history";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_history() {
            $con = new dbconnection();
            $sql = "select history.history_id from history
                    order by history.history_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['history_id'];
            return $first_rec;
        }

        function get_last_history() {
            $con = new dbconnection();
            $sql = "select history.history_id from history
                    order by history.history_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['history_id'];
            return $first_rec;
        }

        function list_result($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from result";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> result </td>
                    <td> Suspect </td><td> Case </td><td> Entry Date </td><td> User </td><td> Note </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['result_id']; ?>
                    </td>
                    <td class="suspect_id_cols result " title="result" >
                        <?php echo $this->_e($row['suspect']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['case']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['note']); ?>
                    </td>


                    <td>
                        <a href="#" class="result_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['result_id']; ?>"  data-table="result">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="result_update_link" style="color: #000080;" data-id_update="<?php echo $row['result_id']; ?>" data-table="result" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_result_suspect($id) {

            $db = new dbconnection();
            $sql = "select   result.suspect from result where result_id=:result_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':result_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['suspect'];
            echo $field;
        }

        function get_chosen_result_case($id) {

            $db = new dbconnection();
            $sql = "select   result.case from result where result_id=:result_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':result_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['case'];
            echo $field;
        }

        function get_chosen_result_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   result.entry_date from result where result_id=:result_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':result_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_result_User($id) {

            $db = new dbconnection();
            $sql = "select   result.User from result where result_id=:result_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':result_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_result_note($id) {

            $db = new dbconnection();
            $sql = "select   result.note from result where result_id=:result_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':result_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['note'];
            echo $field;
        }

        function All_result() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  result_id   from result";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_result() {
            $con = new dbconnection();
            $sql = "select result.result_id from result
                    order by result.result_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['result_id'];
            return $first_rec;
        }

        function get_last_result() {
            $con = new dbconnection();
            $sql = "select result.result_id from result
                    order by result.result_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['result_id'];
            return $first_rec;
        }

        function get_account_category_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account_category.account_category_id,   account_category.name from account_category";
            ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }
 
    

    function get_officer_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select officer.officer_id,   officer.officer_id from officer";
        ?>
        <select class="textbox cbo_officer"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['officer_id'] . ">" . $row['officer_id'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }
 

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

     

    function get_suspect_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select suspect.suspect_id,   suspect.name from suspect";
        ?>
        <select class="textbox cbo_suspect"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['suspect_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_case_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select case.case_id,   case.name from case";
        ?>
        <select class="textbox cbo_case"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['case_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
