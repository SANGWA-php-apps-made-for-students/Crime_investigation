<div class="parts  eighty_centered " style="background-color: #fff; color: #061c11;">   
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Crime investigation
    </div>
</div>    
<div class="parts menu eighty_centered" style="text-align: center;">
     <a href="new_officer.php">officer</a>
    <a href="new_case.php">case</a>
    <a href="new_officer_case.php">officer case</a>
    <a href="new_suspect.php">suspect</a>
 
    <!--    <a href="new_account.php">account</a>
        <a href="new_account_category.php">account_category</a>
        <a href="new_profile.php">profile</a>
        <a href="new_image.php">image</a>
       
       
        <a href="new_evidence.php">evidence</a>
        <a href="new_history.php">history</a>
        <a href="new_result.php">result</a>-->
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
